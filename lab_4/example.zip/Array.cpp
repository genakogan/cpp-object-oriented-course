//#include "pch.h"
#include "Array.h"

Array::Array() :size(1) {
	values = new int[size];
	values[0] = 1;
}

Array::Array(int n) : size(n) {
	values = new int[size];
	for (int i = 0; i < size; i++)
		values[i] = i + 1;
}

Array::Array(const Array& other) : size(other.size) {
	values = new int[size];
	for (int i = 0; i < size; i++)
		values[i] = other.values[i];
}

Array::~Array() {
	delete[] values;
}

void Array::print() const {
	for (int i = 0; i < size; i++)
		cout << values[i] << " ";
	cout << endl;
}

Array Array::ShiftLeft() {
	Array nArray(size);
	for (int i = 0; i < size - 1; i++)
		nArray.values[i] = values[i + 1];
	nArray.values[size - 1] = values[0];
	return nArray;
}

void Array::setValue(int index, int value) {
	if (index >= 0 && index < size)
		values[index] = value;
	else {
		cout << "ERROR: index " << index<< " out of range!" << endl;
	}
}
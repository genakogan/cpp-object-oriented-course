//#include "pch.h"
#ifndef _ARRAY_H
#define _ARRAY_H
#include <iostream>
using namespace std;
class Array {
	private:
		int * values;
		const int size;

	public:
		Array();
		Array(int);
		Array(const Array&);
		~Array();

		void print() const;
		Array ShiftLeft();

		// set
		void setValue(int, int);

		// get
		int getSize() { return size; }
		int* getValues() { return values; }
};
#endif // !_ARRAY_H

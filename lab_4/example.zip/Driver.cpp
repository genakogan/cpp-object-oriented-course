//#include "pch.h"
#include "Array.h"

int main() {
	Array a1, a2(5);
	// Before changes
	a1.print();
	a2.print();

	a1.setValue(0, 6);
	a2.setValue(2, 18);
	a2.setValue(6, 22); // Print ERROR

	// After changes
	a1.print();
	a2.print();

	Array a3(a2);
	a3.print();
	(a3.ShiftLeft()).print();
	Array a4 = a3.ShiftLeft();
	a4.print();

	return 0;
}
//#include "pch.h"
#include <iostream>
#include "CMatrixFun.h"

int main()
{
	CMatrixFun m1(4, 5), m2;
	CMatrixFun m3(m1);
	double ar[4] = { 1, 2, 3, 4 };
	m1.Print();
	m2.Print();
	m3.Print();

	m1.setValue(2, 4, 18);
	m2.setValue(0, 0, 3);

	m1.Print();
	m2.Print();

	cout << (m1.getRow(3))[2] << endl;
	cout << m1.GetValue(1, 4) << endl;

	m1.Transpose();
	m1.Print();

	m1.AddRow(ar, 4);
	m1.Print();

	m1.RemoveColumn(1);
	m1.Print();

	return 0;
}
//#include "pch.h"
#include "CMatrixFun.h"

CMatrixFun::CMatrixFun() {

}

CMatrixFun::CMatrixFun(int r, int c) {
	
}

CMatrixFun::CMatrixFun(const CMatrixFun &other) {
	
}

CMatrixFun::~CMatrixFun() {

}

void CMatrixFun::Print() const {

}

void CMatrixFun::Transpose() {

}

void CMatrixFun::AddRow(double *ar, int size_ar) {

}

void CMatrixFun::RemoveColumn(int colNumber) {

}

bool CMatrixFun::CheckArithmeticSequence() {
	
}

CMatrixFun CMatrixFun::Multiply(const CMatrixFun &other) {

}

CMatrixFun CMatrixFun::MaxRelocate() {

}

void CMatrixFun::setValue(int r, int c, double val) {

}

double CMatrixFun::GetValue(int r, int c) {

}

double* CMatrixFun::getRow(int r) {

}
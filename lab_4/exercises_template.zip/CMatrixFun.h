//#include "pch.h"
#ifndef _CMATRIXFUN_H
#define _CMATRIXFUN_H
#include <iostream>
#include <time.h>        
using namespace std;

class CMatrixFun {
private:
	double **matrix;
	int row;
	int col;

public:
	CMatrixFun();
	CMatrixFun(int, int);
	CMatrixFun(const CMatrixFun&);
	~CMatrixFun();

	void Print() const;
	void Transpose();
	void AddRow(double*, int);
	void RemoveColumn(int);
	CMatrixFun Multiply(const CMatrixFun&);
	bool CheckArithmeticSequence();
	CMatrixFun MaxRelocate();

	// Set
	void setValue(int, int, double);

	// Get
	int getRow() { return row; }
	int getCol() { return col; }
	double GetValue(int, int);
	double* getRow(int);
};
#endif // !_CMATRIXFUN_H
